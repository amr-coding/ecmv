<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.login', []);

$__html = app('livewire')->mount($__name, $__params, 'jgaJUzP', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php /**PATH E:\Upwork\Chander G\Ecommerce\Ecomerce\ecom-app\resources\views/admin/login.blade.php ENDPATH**/ ?>