  <footer class="footer">
      <div class="d-sm-flex justify-content-center justify-content-sm-between">
          <span class="text-muted text-center text-sm-left d-block d-sm-inline-block"> Avacean - Copyright © 2021 All
              rights
              reserved.</span>

      </div>
  </footer>
<?php /**PATH E:\Upwork\Chander G\Ecommerce\Ecomerce\ecom-app\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>