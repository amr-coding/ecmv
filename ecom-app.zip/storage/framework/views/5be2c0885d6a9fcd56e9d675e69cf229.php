
<?php /**PATH E:\Upwork\Chander G\Ecommerce\Ecomerce\ecom-app\resources\views/admin/layouts/layout.blade.php ENDPATH**/ ?>