<x-app-layout>
    <livewire:dashboard />
</x-app-layout>
